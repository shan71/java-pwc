package com.demo.rest.dao;

import java.util.List;

public interface EmpDao {
	public Employee getById(int id);

	public String save(Employee e);

	public String delete(int id);

	public String update(Employee e);

	public List<Employee> getEmpList();
}
