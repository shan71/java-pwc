package com.demo.rest.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmpDaoImpl implements EmpDao {

	@Override
	public Employee getById(int id) {
		Connection conn = null;
		Employee e = new Employee();
		try {
			conn = getConnection();

			Statement st = conn.createStatement();

			ResultSet rs = st.executeQuery("select * from employees where id=" + id);
			while (rs.next()) {
				e.setEmpId(rs.getInt("ID"));
				e.setFirstName(rs.getString("FIRST_NAME"));
				e.setLastName(rs.getString("LAST_NAME"));
				e.setEmail(rs.getString("EMAIL"));
				e.setPhoneNumber(rs.getString("PHONE_NUMBER"));
				e.setSalary(rs.getDouble("SALARY"));
				e.setCommission(rs.getDouble("COMMISSION"));
				e.setJobId(rs.getString("JOB_ID"));
				e.setManagerId(rs.getInt("MANAGER_ID"));
				e.setDeptId(rs.getInt("DEPARTMENT_ID"));
				e.setHireDate(rs.getDate("HIRE_DATE"));
			}

		} catch (ClassNotFoundException ex) {
			System.out.println("Driver Class not Found..");
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return e;
	}

	@Override
	public String save(Employee emp) {
		Connection conn = null;
		String response = "";
		try {
			conn = getConnection();
			PreparedStatement pst = conn
					.prepareStatement("insert into employees(" + "ID,FIRST_NAME,LAST_NAME,EMAIL,PHONE_NUMBER,"
							+ "HIRE_DATE,JOB_ID,SALARY,COMMISSION,MANAGER_ID,DEPARTMENT_ID)"
							+ " values(?,?,?,?,?,?,?,?,?,?,?)");
			pst.setInt(1, emp.getEmpId());
			pst.setString(2, emp.getFirstName());
			pst.setString(3, emp.getLastName());
			pst.setString(4, emp.getEmail());
			pst.setString(5, emp.getPhoneNumber());
			pst.setDate(6, new Date(emp.getHireDate().getTime()));
			pst.setString(7, emp.getJobId());
			pst.setDouble(8, emp.getSalary());
			pst.setDouble(9, emp.getCommission());
			pst.setInt(10, emp.getManagerId());
			pst.setInt(11, emp.getDeptId());
			int count = pst.executeUpdate();
			System.out.println("Rows Inserted : " + count);
			response = "Data Saved";

		} catch (ClassNotFoundException e) {
			System.out.println("Driver Class not Found..");
			response = "Data Not Saved, Problem Occurred";
		} catch (SQLException e) {
			e.printStackTrace();
			response = "Data Not Saved, Problem Occurred";
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return response;
	}

	@Override
	public String delete(int id) {
		Connection conn = null;
		String response = "";
		try {
			conn = getConnection();
			PreparedStatement pst = conn.prepareStatement("delete from employees where id=?");
			pst.setInt(1, id);
			int count = pst.executeUpdate();
			System.out.println("Rows Inserted : " + count);
			response = "Employee Deleted";

		} catch (ClassNotFoundException e) {
			System.out.println("Driver Class not Found..");
			response = "Employee could not be deleted";
		} catch (SQLException e) {
			e.printStackTrace();
			response = "Employee could not be deleted";
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return response;
	}

	@Override
	public String update(Employee e) {
		Connection conn = null;
		String response = "";
		try {
			conn = getConnection();

			PreparedStatement pst = conn.prepareStatement(
					"update employees set FIRST_NAME=?,LAST_NAME=?," + "EMAIL=?,PHONE_NUMBER=?,HIRE_DATE=?,JOB_ID=?,"
							+ "SALARY=?,COMMISSION=?,MANAGER_ID=?,DEPARTMENT_ID=? " + "where ID=?");
			pst.setInt(11, e.getEmpId());
			pst.setString(1, e.getFirstName());
			pst.setString(2, e.getLastName());
			pst.setString(3, e.getEmail());
			pst.setString(4, e.getPhoneNumber());
			pst.setDate(5, new Date(e.getHireDate().getTime()));
			pst.setString(6, e.getJobId());
			pst.setDouble(7, e.getSalary());
			pst.setDouble(8, e.getCommission());
			pst.setInt(9, e.getManagerId());
			pst.setInt(10, e.getDeptId());
			int count = pst.executeUpdate();
			System.out.println("Rows Updated : " + count);
			response = "EMployee Updated";
		} catch (ClassNotFoundException ex) {
			System.out.println("Driver Class not Found..");
			response = "Employee not Updated";
		} catch (SQLException ex) {
			ex.printStackTrace();
			response = "Employee not Updated";
		} finally {
			try {
				conn.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return response;
	}

	@Override
	public List<Employee> getEmpList() {
		Connection conn = null;
		List<Employee> empList = new ArrayList<>();
		try {
			conn = getConnection();
			Statement st = conn.createStatement();

			ResultSet rs = st.executeQuery("select * from employees");
			while (rs.next()) {
				Employee e = new Employee();
				e.setEmpId(rs.getInt("ID"));
				e.setFirstName(rs.getString("FIRST_NAME"));
				e.setLastName(rs.getString("LAST_NAME"));
				e.setEmail(rs.getString("EMAIL"));
				e.setPhoneNumber(rs.getString("PHONE_NUMBER"));
				e.setSalary(rs.getDouble("SALARY"));
				e.setCommission(rs.getDouble("COMMISSION"));
				e.setJobId(rs.getString("JOB_ID"));
				e.setManagerId(rs.getInt("MANAGER_ID"));
				e.setDeptId(rs.getInt("DEPARTMENT_ID"));
				e.setHireDate(rs.getDate("HIRE_DATE"));
				empList.add(e);
			}

		} catch (ClassNotFoundException ex) {
			System.out.println("Driver Class not Found..");
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return empList;
	}

	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "adp", "welcome1");

		} catch (ClassNotFoundException e) {
			System.out.println("Driver Class not Found..");
			throw e;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}
		return conn;
	}
}
