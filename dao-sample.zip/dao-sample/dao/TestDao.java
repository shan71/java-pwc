package com.demo.rest.dao;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TestDao {

	public static void main(String[] args) throws Exception{
		EmpDao dao= new EmpDaoImpl();
		
		Employee e= new Employee();
		e.setEmpId(302);
		e.setFirstName("Scott");
		e.setLastName("Tiger");
		e.setJobId("AD_VP");
		e.setEmail("SCOTTHYD");
		e.setManagerId(100);
		e.setCommission(0);
		e.setSalary(7000);
		e.setDeptId(170);
		e.setPhoneNumber("333.555.3434");
		
		SimpleDateFormat df= new SimpleDateFormat("dd-MMM-yyyy");
		Date date=df.parse("21-FEB-1971");
		
		e.setHireDate(date);
		
		String message=dao.save(e);
		System.out.println(message);

	}

}
