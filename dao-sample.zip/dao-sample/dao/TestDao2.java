package com.demo.rest.dao;

import java.util.List;

public class TestDao2 {

	public static void main(String[] args) throws Exception{
		EmpDao dao= new EmpDaoImpl();
		Employee e= dao.getById(102);
		System.out.println(e.getFirstName()+" "+e.getSalary()+" "+e.getHireDate());

		System.out.println(e);
		
		List<Employee> empList=dao.getEmpList();
		
		for(Employee e1:empList){
			System.out.println(e1);
		}
	}

}
