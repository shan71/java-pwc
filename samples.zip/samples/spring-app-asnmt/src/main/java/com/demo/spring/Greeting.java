package com.demo.spring;

public interface Greeting {

	public String greetMessage();

}
