package com.hsbc.tr.spring.dao;

import com.hsbc.tr.spring.entity.Emp;

public interface EmpDao {

	public String save(Emp e);
}
