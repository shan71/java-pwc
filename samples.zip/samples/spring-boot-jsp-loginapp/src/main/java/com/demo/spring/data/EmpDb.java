package com.demo.spring.data;

public class EmpDb {

}
